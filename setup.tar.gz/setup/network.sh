rmmod b43
rmmod bcma
rmmod wl
modprobe wl

wifi-menu
