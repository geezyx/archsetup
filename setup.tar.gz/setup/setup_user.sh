#!/bin/bash

yay -Syu keybase-bin keybase-zsh-completion-git

sh -c "$(curl -fsSL https://raw.githubusercontent.com/robbyrussell/oh-my-zsh/master/tools/install.sh)"

cp .neofetch ~/
cp .xinitrc ~/
cp .Xresources ~/
cp .zshrc ~/
mkdir -p ~/.config/i3
cp .config/i3/config ~/.config/i3

