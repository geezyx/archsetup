#!/bin/bash

ln -sf /usr/share/zoneinfo/US/Eastern /etc/localtime
hwclock --systohc --utc

sed -i 's/#en_US.UTF-8 UTF-8/en_US.UTF-8 UTF-8/' /etc/locale.gen
sed -i 's/#en_US ISO-8859-1/en_US ISO-8859-1/' /etc/locale.gen
locale-gen

tee <<'EOF' /etc/hostname
foo
EOF

tee <<'EOF' /etc/hosts
# Static table lookup for hostnames.
# See hosts(5) for details.

127.0.0.1   localhost
::1         localhost
127.0.1.1   foo.local foo

EOF
pacman -Syu grub os-prober

sed -i 's|#[community]|[community]|' /etc/pacman.conf
sed -i 's|#Include = /etc/pacman.d/mirrorlist|Include = /etc/pacman.d/mirrorlist|' /etc/pacman.conf

pacman -Syu zsh vim git

useradd -m -G wheel,storage,power -s /bin/zsh baz

# grub setup
pacman -S grub efibootmgr dosfstools os-prober mtools
mkdir -p /boot/grub
mkdir -p /boot/EFI
mount /dev/sda1 /boot/EFI
grub-install --target=x86_64-efi --bootloader-id=grub_uefi --recheck
grub-mkconfig -o /boot/grub/grub.cfg

# fonts
mkdir -p /usr/local/share/fonts/f
cp ./Fura_Code_Retina_Nerd_Font_Complete_Mono.otf /usr/local/share/fonts/f
pacman -Syu tamsyn-font
tee <<'EOF' /etc/vconsole.conf
KEYMAP="us"
FONT="Tamsyn8x16r"
EOF
fc-cache -f -v

# mkinitcpio setup
sed -i 's/HOOKS=/#HOOKS=/' /etc/mkinitcpio.conf
tee -a <<'EOF' /etc/mkinitcpio.conf
HOOKS=(base systemd autodetect modconf block keyboard sd-vconsole fsck filesystems)
EOF
mkinitcpio -p linux

# xorg setup
pacman -Syu xf86-video-intel
pacman -Syu xorg-server
pacman -Syu xorg xorg-xinit

mkdir -p /etc/X11/xorg.conf.d && sudo tee <<'EOF' /etc/X11/xorg.conf.d/90-touchpad.conf 1> /dev/null
Section "InputClass"
        Identifier "touchpad"
        MatchIsTouchpad "on"
        Driver "libinput"
        Option "Tapping" "on"
EndSection

EOF

# i3-gaps setup

pacman -Syu i3

# yay setup

git clone https://aur.archlinux.org/yay.git
cd yay
makepkg -si
cd ../
rm -rf yay

# extra packages setup

pacman -Syu bat lsd rxvt-unicode chromium firefox neofetch light

# network setup

pacman -Syu networkmanager
systemctl stop dhcpcd
systemctl disable dhcpcd
systemctl enable NetworkManager
systemctl start NetworkManager

echo "REMAINING SETUP"
echo "passwd root"
echo "passwd baz"
